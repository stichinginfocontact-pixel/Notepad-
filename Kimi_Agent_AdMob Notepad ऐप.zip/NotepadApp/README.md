# Notepad App - Kotlin Android

A simple, beautiful, and feature-rich Notepad application built with Kotlin for Android. This app includes AdMob integration, Room database for local storage, and a clean Material Design interface.

## Features

- Create, edit, and delete notes
- Search notes by title or content
- Grid and List view layouts
- Share notes with other apps
- Dark mode support
- AdMob Banner and Interstitial ads
- No signup/login required
- Beautiful Material Design UI
- Long press to delete notes
- Auto-save on back press

## Project Structure

```
NotepadApp/
├── app/
│   ├── src/main/java/com/notepad/easy/
│   │   ├── data/
│   │   │   ├── Note.kt              # Note entity
│   │   │   ├── NoteDao.kt           # Data Access Object
│   │   │   ├── NoteDatabase.kt      # Room Database
│   │   │   ├── NoteRepository.kt    # Repository pattern
│   │   │   └── NoteViewModel.kt     # ViewModel
│   │   ├── adapter/
│   │   │   └── NoteAdapter.kt       # RecyclerView Adapter
│   │   └── ui/
│   │       ├── MainActivity.kt      # Main screen with notes list
│   │       └── NoteActivity.kt      # Add/Edit note screen
│   ├── src/main/res/
│   │   ├── layout/                  # XML layouts
│   │   ├── drawable/                # Icons and drawables
│   │   ├── menu/                    # Menu items
│   │   ├── values/                  # Colors, strings, themes
│   │   └── mipmap-*/                # App icons
│   └── build.gradle                 # App-level build config
├── build.gradle                     # Project-level build config
└── settings.gradle                  # Project settings
```

## Setup Instructions

### 1. Open in Android Studio

1. Launch Android Studio
2. Click on "Open an existing Android Studio project"
3. Select the `NotepadApp` folder
4. Wait for Gradle sync to complete

### 2. Configure AdMob (IMPORTANT)

The app currently uses **TEST Ad Unit IDs**. Before publishing, you must replace them with your own:

#### In `MainActivity.kt`:
```kotlin
// Replace these TEST IDs with your actual AdMob IDs
const val ADMOB_APP_ID = "ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX"
const val BANNER_AD_UNIT_ID = "ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX"
const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX"
```

#### In `AndroidManifest.xml`:
```xml
<meta-data
    android:name="com.google.android.gms.ads.APPLICATION_ID"
    android:value="ca-app-pub-XXXXXXXXXXXXXXXX~XXXXXXXXXX" />
```

#### In `activity_main.xml` and `activity_note.xml`:
```xml
app:adUnitId="ca-app-pub-XXXXXXXXXXXXXXXX/XXXXXXXXXX"
```

### 3. Get AdMob IDs

1. Go to [AdMob Console](https://apps.admob.com/)
2. Create a new app
3. Create ad units (Banner and Interstitial)
4. Copy the App ID and Ad Unit IDs
5. Replace the test IDs in the code

### 4. Build and Run

1. Connect your Android device or start an emulator
2. Click the "Run" button (▶) in Android Studio
3. Select your device
4. The app will install and launch automatically

## App Details

- **Package Name:** `com.notepad.easy`
- **App Name:** Notepad
- **Min SDK:** 21 (Android 5.0)
- **Target SDK:** 34 (Android 14)
- **Language:** Kotlin

## Dependencies

| Library | Version | Purpose |
|---------|---------|---------|
| AndroidX Core | 1.12.0 | Core Android functionality |
| AppCompat | 1.6.1 | Backward compatibility |
| Material Design | 1.11.0 | UI components |
| Room | 2.6.1 | Local database |
| Lifecycle | 2.7.0 | ViewModel and LiveData |
| Coroutines | 1.7.3 | Async operations |
| AdMob | 22.6.0 | Google Mobile Ads |
| RecyclerView | 1.3.2 | List display |

## Screenshots

The app features:
- Clean home screen with notes list
- Beautiful card-based note items
- Simple note editing interface
- Search functionality
- Empty state illustration

## Key Features Explained

### Room Database
- Notes are stored locally using Room persistence library
- Data survives app restarts
- Efficient queries with LiveData

### AdMob Integration
- Banner ads displayed at the top of screens
- Interstitial ads shown when creating new notes
- Test IDs included for development

### Material Design
- Modern UI with CardView
- Floating Action Button for quick actions
- Smooth animations and transitions
- Dark mode support

## Customization

### Change App Colors
Edit `res/values/colors.xml`:
```xml
<color name="colorPrimary">#YOUR_COLOR</color>
<color name="colorPrimaryDark">#YOUR_DARK_COLOR</color>
<color name="colorAccent">#YOUR_ACCENT_COLOR</color>
```

### Change App Name
Edit `res/values/strings.xml`:
```xml
<string name="app_name">Your App Name</string>
```

## Building Release APK

1. Go to `Build` → `Generate Signed Bundle/APK`
2. Select `APK`
3. Create or select a keystore
4. Choose `release` build type
5. Click `Finish`
6. The APK will be generated in `app/release/`

## Troubleshooting

### Gradle Sync Issues
```bash
# Try cleaning and rebuilding
./gradlew clean
./gradlew build
```

### AdMob Ads Not Showing
- Check internet connection
- Verify Ad Unit IDs are correct
- Use test IDs during development
- Wait 24-48 hours for new AdMob accounts

### Database Issues
- Uninstall and reinstall the app
- Check Room schema migrations
- Clear app data from settings

## License

This project is open source and available for personal and commercial use.

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review Android and AdMob documentation
3. Search for similar issues online

---

**Happy Coding! 🚀**

package com.notepad.easy.ui

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.SearchView
nimport androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.gms.ads.*
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.notepad.easy.R
import com.notepad.easy.adapter.NoteAdapter
import com.notepad.easy.data.Note
import com.notepad.easy.data.NoteViewModel

class MainActivity : AppCompatActivity() {
    
    private lateinit var noteViewModel: NoteViewModel
    private lateinit var noteAdapter: NoteAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var fabAdd: FloatingActionButton
    private lateinit var emptyView: View
    
    private var interstitialAd: InterstitialAd? = null
    private var isGridLayout = false
    
    companion object {
        const val EXTRA_NOTE_ID = "extra_note_id"
        const val ADMOB_APP_ID = "ca-app-pub-3940256099942544~3347511713" // Test App ID
        const val BANNER_AD_UNIT_ID = "ca-app-pub-3940256099942544/6300978111" // Test Banner ID
        const val INTERSTITIAL_AD_UNIT_ID = "ca-app-pub-3940256099942544/1033173712" // Test Interstitial ID
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        // Initialize AdMob
        MobileAds.initialize(this) {}
        
        // Setup Banner Ad
        setupBannerAd()
        
        // Load Interstitial Ad
        loadInterstitialAd()
        
        // Initialize Views
        recyclerView = findViewById(R.id.recyclerView)
        fabAdd = findViewById(R.id.fabAdd)
        emptyView = findViewById(R.id.emptyView)
        
        // Setup RecyclerView
        setupRecyclerView()
        
        // Setup ViewModel
        noteViewModel = ViewModelProvider(this)[NoteViewModel::class.java]
        
        noteViewModel.allNotes.observe(this) { notes ->
            notes?.let {
                noteAdapter.submitList(it)
                updateEmptyView(it.isEmpty())
            }
        }
        
        // FAB Click Listener
        fabAdd.setOnClickListener {
            showInterstitialAd()
            val intent = Intent(this, NoteActivity::class.java)
            startActivity(intent)
        }
    }
    
    private fun setupBannerAd() {
        val adView = findViewById<AdView>(R.id.adView)
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)
        
        adView.adListener = object : AdListener() {
            override fun onAdLoaded() {
                // Ad loaded successfully
            }
            
            override fun onAdFailedToLoad(adError: LoadAdError) {
                // Ad failed to load
            }
        }
    }
    
    private fun loadInterstitialAd() {
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(this, INTERSTITIAL_AD_UNIT_ID, adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                }
                
                override fun onAdFailedToLoad(adError: LoadAdError) {
                    interstitialAd = null
                }
            }
        )
    }
    
    private fun showInterstitialAd() {
        interstitialAd?.let { ad ->
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    interstitialAd = null
                    loadInterstitialAd()
                }
                
                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    interstitialAd = null
                }
            }
            ad.show(this)
        }
    }
    
    private fun setupRecyclerView() {
        noteAdapter = NoteAdapter(
            onItemClick = { note ->
                val intent = Intent(this, NoteActivity::class.java)
                intent.putExtra(EXTRA_NOTE_ID, note.id)
                startActivity(intent)
            },
            onItemLongClick = { note ->
                showDeleteDialog(note)
                true
            }
        )
        
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = noteAdapter
    }
    
    private fun updateEmptyView(isEmpty: Boolean) {
        if (isEmpty) {
            emptyView.visibility = View.VISIBLE
            recyclerView.visibility = View.GONE
        } else {
            emptyView.visibility = View.GONE
            recyclerView.visibility = View.VISIBLE
        }
    }
    
    private fun showDeleteDialog(note: Note) {
        AlertDialog.Builder(this)
            .setTitle("Delete Note")
            .setMessage("Are you sure you want to delete this note?")
            .setPositiveButton("Delete") { _, _ ->
                noteViewModel.delete(note)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        
        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView
        
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }
            
            override fun onQueryTextChange(newText: String?): Boolean {
                newText?.let {
                    if (it.isNotEmpty()) {
                        noteViewModel.searchNotes(it).observe(this@MainActivity) { notes ->
                            noteAdapter.submitList(notes)
                        }
                    } else {
                        noteViewModel.allNotes.observe(this@MainActivity) { notes ->
                            noteAdapter.submitList(notes)
                        }
                    }
                }
                return true
            }
        })
        
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_delete_all -> {
                showDeleteAllDialog()
                true
            }
            R.id.action_toggle_layout -> {
                toggleLayout()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    private fun toggleLayout() {
        isGridLayout = !isGridLayout
        if (isGridLayout) {
            recyclerView.layoutManager = GridLayoutManager(this, 2)
        } else {
            recyclerView.layoutManager = LinearLayoutManager(this)
        }
    }
    
    private fun showDeleteAllDialog() {
        AlertDialog.Builder(this)
            .setTitle("Delete All Notes")
            .setMessage("Are you sure you want to delete all notes? This action cannot be undone.")
            .setPositiveButton("Delete All") { _, _ ->
                noteViewModel.deleteAll()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

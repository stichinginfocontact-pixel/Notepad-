package com.notepad.easy.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class NoteViewModel(application: Application) : AndroidViewModel(application) {
    
    private val repository: NoteRepository
    val allNotes: LiveData<List<Note>>
    
    init {
        val noteDao = NoteDatabase.getDatabase(application).noteDao()
        repository = NoteRepository(noteDao)
        allNotes = repository.allNotes
    }
    
    fun insert(note: Note) = viewModelScope.launch {
        repository.insert(note)
    }
    
    fun update(note: Note) = viewModelScope.launch {
        repository.update(note)
    }
    
    fun delete(note: Note) = viewModelScope.launch {
        repository.delete(note)
    }
    
    fun deleteById(noteId: Int) = viewModelScope.launch {
        repository.deleteById(noteId)
    }
    
    fun deleteAll() = viewModelScope.launch {
        repository.deleteAll()
    }
    
    suspend fun getNoteById(noteId: Int): Note? {
        return repository.getNoteById(noteId)
    }
    
    fun searchNotes(query: String): LiveData<List<Note>> {
        return repository.searchNotes(query)
    }
}

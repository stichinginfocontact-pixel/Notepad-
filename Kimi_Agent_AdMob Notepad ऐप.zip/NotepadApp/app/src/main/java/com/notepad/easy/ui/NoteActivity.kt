package com.notepad.easy.ui

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdView
import com.notepad.easy.R
import com.notepad.easy.data.Note
import com.notepad.easy.data.NoteViewModel
import kotlinx.coroutines.launch

class NoteActivity : AppCompatActivity() {
    
    private lateinit var noteViewModel: NoteViewModel
    private lateinit var etTitle: EditText
    private lateinit var etContent: EditText
    
    private var noteId: Int = -1
    private var isEditMode = false
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_note)
        
        // Enable back button
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        
        // Initialize Views
        etTitle = findViewById(R.id.etTitle)
        etContent = findViewById(R.id.etContent)
        
        // Setup Banner Ad
        val adView = findViewById<AdView>(R.id.adViewNote)
        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)
        
        // Setup ViewModel
        noteViewModel = ViewModelProvider(this)[NoteViewModel::class.java]
        
        // Check if editing existing note
        noteId = intent.getIntExtra(MainActivity.EXTRA_NOTE_ID, -1)
        if (noteId != -1) {
            isEditMode = true
            supportActionBar?.title = "Edit Note"
            loadNote()
        } else {
            supportActionBar?.title = "New Note"
        }
    }
    
    private fun loadNote() {
        lifecycleScope.launch {
            val note = noteViewModel.getNoteById(noteId)
            note?.let {
                etTitle.setText(it.title)
                etContent.setText(it.content)
            }
        }
    }
    
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_note, menu)
        return true
    }
    
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            R.id.action_save -> {
                saveNote()
                true
            }
            R.id.action_share -> {
                shareNote()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
    
    private fun saveNote() {
        val title = etTitle.text.toString().trim()
        val content = etContent.text.toString().trim()
        
        if (title.isEmpty() && content.isEmpty()) {
            Toast.makeText(this, "Please enter title or content", Toast.LENGTH_SHORT).show()
            return
        }
        
        val note = Note(
            id = if (isEditMode) noteId else 0,
            title = title,
            content = content
        )
        
        if (isEditMode) {
            noteViewModel.update(note)
            Toast.makeText(this, "Note updated", Toast.LENGTH_SHORT).show()
        } else {
            noteViewModel.insert(note)
            Toast.makeText(this, "Note saved", Toast.LENGTH_SHORT).show()
        }
        
        finish()
    }
    
    private fun shareNote() {
        val title = etTitle.text.toString().trim()
        val content = etContent.text.toString().trim()
        
        if (title.isEmpty() && content.isEmpty()) {
            Toast.makeText(this, "Nothing to share", Toast.LENGTH_SHORT).show()
            return
        }
        
        val shareText = buildString {
            if (title.isNotEmpty()) {
                append(title)
                append("\n\n")
            }
            append(content)
        }
        
        val shareIntent = android.content.Intent().apply {
            action = android.content.Intent.ACTION_SEND
            type = "text/plain"
            putExtra(android.content.Intent.EXTRA_SUBJECT, title)
            putExtra(android.content.Intent.EXTRA_TEXT, shareText)
        }
        
        startActivity(android.content.Intent.createChooser(shareIntent, "Share via"))
    }
    
    override fun onBackPressed() {
        saveNote()
        super.onBackPressed()
    }
}

package com.notepad.easy.data

import androidx.lifecycle.LiveData

class NoteRepository(private val noteDao: NoteDao) {
    
    val allNotes: LiveData<List<Note>> = noteDao.getAllNotes()
    
    suspend fun insert(note: Note): Long {
        return noteDao.insert(note)
    }
    
    suspend fun update(note: Note) {
        noteDao.update(note)
    }
    
    suspend fun delete(note: Note) {
        noteDao.delete(note)
    }
    
    suspend fun deleteById(noteId: Int) {
        noteDao.deleteById(noteId)
    }
    
    suspend fun deleteAll() {
        noteDao.deleteAll()
    }
    
    suspend fun getNoteById(noteId: Int): Note? {
        return noteDao.getNoteById(noteId)
    }
    
    fun searchNotes(query: String): LiveData<List<Note>> {
        return noteDao.searchNotes(query)
    }
}
